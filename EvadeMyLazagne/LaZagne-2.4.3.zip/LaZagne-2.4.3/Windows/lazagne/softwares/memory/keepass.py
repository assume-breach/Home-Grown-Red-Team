# -*- coding: utf-8 -*- 
#comment2

import traceback

from . import libkeepass
from lazagne.config.constant import constant
from lazagne.config.module_info import ModuleInfo

#comment5
class Keepass(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'keepass', 'memory')

    def run(self):
        #comment1
        if constant.keepass:
            res = []
            for db in constant.keepass:
                try:
                    with libkeepass.open(db.values()[0][u'Database'],
                                         password=db.get(u"KcpPassword", {}).get(u'Password'),
                                         keyfile=db.get(u"KcpKeyFile", {}).get(u'KeyFilePath')) as kdb:
                        res.extend(kdb.to_dic())
                except Exception:
                    self.debug(traceback.format_exc())
            return res

