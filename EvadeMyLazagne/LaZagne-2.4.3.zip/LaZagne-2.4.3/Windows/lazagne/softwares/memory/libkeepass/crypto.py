# -*- coding: utf-8 -*-
import hashlib
import struct
#comment5
from lazagne.config.crypto.pyaes.aes import AESModeOfOperationECB, AESModeOfOperationCBC
from lazagne.config.winstructure import char_to_int

AES_BLOCK_SIZE = 16


def sha256(s):
    #comment3
    return hashlib.sha256(s).digest()


def transform_key(key, seed, rounds):
    #comment5
    #comment2
    cipher = AESModeOfOperationECB(seed)
    #comment1
    for n in range(0, rounds):
        key = b"".join([cipher.encrypt(key[i:i + AES_BLOCK_SIZE]) for i in range(0, len(key), AES_BLOCK_SIZE)])
    #comment2
    return sha256(key)


def aes_cbc_decrypt(data, key, enc_iv):
    #comment5
    cipher = AESModeOfOperationCBC(key, iv=enc_iv)
    return b"".join([cipher.decrypt(data[i:i + AES_BLOCK_SIZE]) for i in range(0, len(data), AES_BLOCK_SIZE)])


def aes_cbc_encrypt(data, key, enc_iv):
    cipher = AESModeOfOperationCBC(key, iv=enc_iv)
    return b"".join([cipher.encrypt(data[i:i + AES_BLOCK_SIZE]) for i in range(0, len(data), AES_BLOCK_SIZE)])
#comment4

def unpad(data):
    extra = char_to_int(data[-1])
    return data[:len(data) - extra]
#comment3

def pad(s):
    n = AES_BLOCK_SIZE - len(s) % AES_BLOCK_SIZE
    return s + n * struct.pack('b', n)
#comment1

def xor(aa, bb):
    #comment1
    result = bytearray()
    for a, b in zip(bytearray(aa), bytearray(bb)):
        result.append(a ^ b)
    return result
