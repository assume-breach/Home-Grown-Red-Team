#!/usr/bin/env python
# coding: utf-8

#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
from array import array
from struct import Struct
from lazagne.config.winstructure import char_to_int

little_u64 = Struct("<Q")  #comment1#comment2#comment3#comment4#comment1#comment2#comment3
#comment1#comment2#comment3#comment4

little16_i32 = Struct("<16i")  # 16 little-endian 32-bit signed ints.
little4_i32 = Struct("<4i")  # 4 little-endian 32-bit signed ints.
little2_i32 = Struct("<2i")  # 2 little-endian 32-bit signed ints.

_version = 'p3.2'

try:
    long
    xrange
except NameError:
    long = int
    xrange = range


#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4

class Salsa20(object):
    def __init__(self, key=None, iv=None, rounds=20):
        self._lastChunk64 = True
        self._IVbitlen = 64  # must be 64 bits
        self.ctx = [0] * 16
        if key:
            self.set_key(key)
        if iv:
            self.set_iv(iv)

        self.set_rounds(rounds)

    def set_key(self, key):
        assert type(key) == str
        ctx = self.ctx
        if len(key) == 32:  # recommended
            constants = "expand 32-byte k"
            ctx[1], ctx[2], ctx[3], ctx[4] = little4_i32.unpack(key[0:16])
            ctx[11], ctx[12], ctx[13], ctx[14] = little4_i32.unpack(key[16:32])
        elif len(key) == 16:
            constants = "expand 16-byte k"
            ctx[1], ctx[2], ctx[3], ctx[4] = little4_i32.unpack(key[0:16])
            ctx[11], ctx[12], ctx[13], ctx[14] = little4_i32.unpack(key[0:16])
        else:
            raise Exception("key length isn't 32 or 16 bytes.")
        ctx[0], ctx[5], ctx[10], ctx[15] = little4_i32.unpack(constants)

    def set_iv(self, iv):
        assert type(iv) == str
        assert len(iv) * 8 == 64, 'nonce (IV) not 64 bits'
        self.iv = iv
        ctx = self.ctx
        ctx[6], ctx[7] = little2_i32.unpack(iv)
        ctx[8], ctx[9] = 0, 0  # Reset the block counter.

    set_nonce = set_iv  # support an alternate name

    def set_counter(self, counter):
        assert (type(counter) in (int, long))
        assert (0 <= counter < 1 << 64), "counter < 0 or >= 2**64"
        ctx = self.ctx
        ctx[8], ctx[9] = little2_i32.unpack(little_u64.pack(counter))

    def get_counter(self):
        return little_u64.unpack(little2_i32.pack(*self.ctx[8:10]))[0]

    def set_rounds(self, rounds, testing=False):
        assert testing or rounds in [8, 12, 20], 'rounds must be 8, 12, 20'
        self.rounds = rounds

    def encrypt_bytes(self, data):
        assert type(data) == str, 'data must be byte string'
        assert self._lastChunk64, 'previous chunk not multiple of 64 bytes'
        lendata = len(data)
        munged = array('c', '\x00' * lendata)
        for i in xrange(0, lendata, 64):
            h = salsa20_wordtobyte(self.ctx, self.rounds, check_rounds=False)
            self.set_counter((self.get_counter() + 1) % 2 ** 64)
            # Stopping at 2^70 bytes per nonce is user's responsibility.
            for j in xrange(min(64, lendata - i)):
                munged[i + j] = chr(char_to_int(data[i + j]) ^ char_to_int(h[j]))

        self._lastChunk64 = not lendata % 64
        return munged.tostring()

    decrypt_bytes = encrypt_bytes  # encrypt and decrypt use same function


#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1

def salsa20_wordtobyte(input, n_rounds=20, check_rounds=True):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3

    assert (type(input) in (list, tuple) and len(input) == 16)
    assert (not check_rounds or (n_rounds in [8, 12, 20]))

    x = list(input)

    def XOR(a, b):
        return a ^ b

    ROTATE = rot32
    PLUS = add32

    for i in range(n_rounds / 2):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        x[4] = XOR(x[4], ROTATE(PLUS(x[0], x[12]), 7))
        x[8] = XOR(x[8], ROTATE(PLUS(x[4], x[0]), 9))
        x[12] = XOR(x[12], ROTATE(PLUS(x[8], x[4]), 13))
        x[0] = XOR(x[0], ROTATE(PLUS(x[12], x[8]), 18))
        x[9] = XOR(x[9], ROTATE(PLUS(x[5], x[1]), 7))
        x[13] = XOR(x[13], ROTATE(PLUS(x[9], x[5]), 9))
        x[1] = XOR(x[1], ROTATE(PLUS(x[13], x[9]), 13))
        x[5] = XOR(x[5], ROTATE(PLUS(x[1], x[13]), 18))
        x[14] = XOR(x[14], ROTATE(PLUS(x[10], x[6]), 7))
        x[2] = XOR(x[2], ROTATE(PLUS(x[14], x[10]), 9))
        x[6] = XOR(x[6], ROTATE(PLUS(x[2], x[14]), 13))
        x[10] = XOR(x[10], ROTATE(PLUS(x[6], x[2]), 18))
        x[3] = XOR(x[3], ROTATE(PLUS(x[15], x[11]), 7))
        x[7] = XOR(x[7], ROTATE(PLUS(x[3], x[15]), 9))
        x[11] = XOR(x[11], ROTATE(PLUS(x[7], x[3]), 13))
        x[15] = XOR(x[15], ROTATE(PLUS(x[11], x[7]), 18))

        x[1] = XOR(x[1], ROTATE(PLUS(x[0], x[3]), 7))
        x[2] = XOR(x[2], ROTATE(PLUS(x[1], x[0]), 9))
        x[3] = XOR(x[3], ROTATE(PLUS(x[2], x[1]), 13))
        x[0] = XOR(x[0], ROTATE(PLUS(x[3], x[2]), 18))
        x[6] = XOR(x[6], ROTATE(PLUS(x[5], x[4]), 7))
        x[7] = XOR(x[7], ROTATE(PLUS(x[6], x[5]), 9))
        x[4] = XOR(x[4], ROTATE(PLUS(x[7], x[6]), 13))
        x[5] = XOR(x[5], ROTATE(PLUS(x[4], x[7]), 18))
        x[11] = XOR(x[11], ROTATE(PLUS(x[10], x[9]), 7))
        x[8] = XOR(x[8], ROTATE(PLUS(x[11], x[10]), 9))
        x[9] = XOR(x[9], ROTATE(PLUS(x[8], x[11]), 13))
        x[10] = XOR(x[10], ROTATE(PLUS(x[9], x[8]), 18))
        x[12] = XOR(x[12], ROTATE(PLUS(x[15], x[14]), 7))
        x[13] = XOR(x[13], ROTATE(PLUS(x[12], x[15]), 9))
        x[14] = XOR(x[14], ROTATE(PLUS(x[13], x[12]), 13))
        x[15] = XOR(x[15], ROTATE(PLUS(x[14], x[13]), 18))

    for i in range(len(input)):
        x[i] = PLUS(x[i], input[i])
    return little16_i32.pack(*x)


#comment1#comment2#comment3#comment4

def trunc32(w):
    #comment1#comment2#comment3#comment4
    w = int((w & 0x7fffFFFF) | -(w & 0x80000000))
    assert type(w) == int
    return w


def add32(a, b):
   #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    lo = (a & 0xFFFF) + (b & 0xFFFF)
    hi = (a >> 16) + (b >> 16) + (lo >> 16)
    return (-(hi & 0x8000) | (hi & 0x7FFF)) << 16 | (lo & 0xFFFF)


def rot32(w, n_left):
    #comment1#comment2#comment3#comment4
    n_left &= 31  # which makes nLeft >= 0
    if n_left == 0:
        return w

    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    #comment1#comment2#comment3#comment4
    RRR = (((w >> 1) & 0x7fffFFFF) >> (31 - n_left))
    sLLLLLL = -((1 << (31 - n_left)) & w) | (0x7fffFFFF >> n_left) & w
    return RRR | (sLLLLLL << n_left)

#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
