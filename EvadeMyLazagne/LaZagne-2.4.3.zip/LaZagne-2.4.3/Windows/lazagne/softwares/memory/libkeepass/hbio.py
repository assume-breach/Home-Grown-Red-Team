# -*- coding: utf-8 -*-
import hashlib
import io
import struct

#comment3
BLOCK_LENGTH = 1024 * 1024

try:
    file_types = (file, io.IOBase)
except NameError:
    file_types = (io.IOBase,)

#comment5

def read_int(stream, length):
    try:
        return struct.unpack('<I', stream.read(length))[0]
    except Exception:
        return None


class HashedBlockIO(io.BytesIO):
    #comment1

    def __init__(self, block_stream=None, bytes=None):
        io.BytesIO.__init__(self)
        input_stream = None
        if block_stream is not None:
            if not (isinstance(block_stream, io.IOBase) or isinstance(block_stream, file_types)):
                raise TypeError('Stream does not have the buffer interface.')
            input_stream = block_stream
        elif bytes is not None:
            input_stream = io.BytesIO(bytes)
        if input_stream is not None:
            self.read_block_stream(input_stream)

    def read_block_stream(self, block_stream):
        #comment4
        if not (isinstance(block_stream, io.IOBase) or isinstance(block_stream, file_types)):
            raise TypeError('Stream does not have the buffer interface.')
        while True:
            data = self._next_block(block_stream)
            if not self.write(data):
                break
        self.seek(0)

    def _next_block(self, block_stream):
        #comment5
        index = read_int(block_stream, 4)
        bhash = block_stream.read(32)
        length = read_int(block_stream, 4)

        if length > 0:
            data = block_stream.read(length)
            if hashlib.sha256(data).digest() == bhash:
                return data
            else:
                raise IOError('Block hash mismatch error.')
        return bytes()

    def write_block_stream(self, stream, block_length=BLOCK_LENGTH):
        #comment1
        if not (isinstance(stream, io.IOBase) or isinstance(stream, file_types)):
            raise TypeError('Stream does not have the buffer interface.')
        index = 0
        self.seek(0)
        while True:
            data = self.read(block_length)
            if data:
                stream.write(struct.pack('<I', index))
                stream.write(hashlib.sha256(data).digest())
                stream.write(struct.pack('<I', len(data)))
                stream.write(data)
                index += 1
            else:
                stream.write(struct.pack('<I', index))
                stream.write('\x00' * 32)
                stream.write(struct.pack('<I', 0))
                break
