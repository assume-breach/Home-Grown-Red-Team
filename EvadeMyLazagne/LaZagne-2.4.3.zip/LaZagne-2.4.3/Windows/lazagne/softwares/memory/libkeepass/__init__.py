# -*- coding: utf-8 -*-
import io
from contextlib import contextmanager
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
from .common import read_signature
# from kdb3 import KDB3Reader, KDB3_SIGNATURE
from .kdb4 import KDB4Reader, KDB4_SIGNATURE

BASE_SIGNATURE = 0x9AA2D903

_kdb_readers = {
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    KDB4_SIGNATURE[1]: KDB4Reader,
    }

@contextmanager
def open(filename, **credentials):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    kdb = None
    try:
        with io.open(filename, 'rb') as stream:
            signature = read_signature(stream)
            cls = get_kdb_reader(signature)
            kdb = cls(stream, **credentials)
            yield kdb
            kdb.close()
    except Exception:
        if kdb: kdb.close()
        raise

def add_kdb_reader(sub_signature, cls):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
    _kdb_readers[sub_signature] = cls

def get_kdb_reader(signature):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    if signature[0] != BASE_SIGNATURE:
        raise IOError('Unknown base signature.')
    
    if signature[1] not in _kdb_readers:
        raise IOError('Unknown sub signature.')
    
    return _kdb_readers[signature[1]]

