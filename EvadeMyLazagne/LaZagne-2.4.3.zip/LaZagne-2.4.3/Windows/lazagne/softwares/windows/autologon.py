# -*- coding: utf-8 -*- 
try: 
    import _winreg as winreg
except ImportError:
    import winreg
#comment3
from lazagne.config.module_info import ModuleInfo
from lazagne.config.winstructure import *
#comment2
#comment1
class Autologon(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'autologon', 'windows', registry_used=True, system_module=True)
#comment3
    def run(self):
        pwd_found = []
        try:
            hkey = OpenKey(HKEY_LOCAL_MACHINE, 'SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon')
            if int(winreg.QueryValueEx(hkey, 'AutoAdminLogon')[0]) == 1:
                self.debug(u'Autologin enabled')
#comment1
                keys = {
                    'DefaultDomainName': '',
                    'DefaultUserName': '',
                    'DefaultPassword': '',
                    'AltDefaultDomainName': '',
                    'AltDefaultUserName': '',
                    'AltDefaultPassword': '',
                }
#comment2
                to_remove = []
                for k in keys:
                    try:
                        keys[k] = str(winreg.QueryValueEx(hkey, k)[0])
                    except Exception:
                        to_remove.append(k)
#comment1
                for r in to_remove:
                    keys.pop(r)

                if keys:
                    pwd_found.append(keys)
#comment4
        except Exception as e:
            self.debug(str(e))
#comment1
        return pwd_found
