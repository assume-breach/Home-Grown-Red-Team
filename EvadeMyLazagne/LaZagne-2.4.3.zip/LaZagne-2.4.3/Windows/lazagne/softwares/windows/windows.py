# -*- coding: utf-8 -*-
try: 
    import _winreg as winreg
except ImportError:
    import winreg
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
from lazagne.config.module_info import ModuleInfo
from lazagne.config.winstructure import OpenKey, HKEY_LOCAL_MACHINE
from lazagne.config.constant import constant
from lazagne.config.users import get_username_winapi
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4
class WindowsPassword(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'windows', 'windows')
        self.current_user = get_username_winapi()
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def is_in_domain(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        try:
            key = OpenKey(HKEY_LOCAL_MACHINE, r'SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Group Policy\\History\\')
            val, _ = winreg.QueryValueEx(key, 'DCName')
            winreg.CloseKey(key)
            return val
        except Exception:
            return False

    def run(self):
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        if constant.pypykatz_result.get(self.current_user, None):
            if 'Password' in constant.pypykatz_result[self.current_user]:
               #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                self.info('User has already be found: {password}'.format(
                    password=constant.pypykatz_result[self.current_user]['Password'])
                )
                return

        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        pwd_found = []
        if constant.user_dpapi and constant.user_dpapi.unlocked:
            #comment1#comment2#comment3#comment4#comment1#comment2#comment3
            password = constant.user_dpapi.get_cleartext_password()
            if password:
                pwd_found.append({
                    'Login': constant.username,
                    'Password': password
                })
            else:
                #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
                self.info(
                    u'Windows passwords not found.\n'
                    u'Try to bruteforce this hash (using john or hashcat)'
                )
                if constant.user_dpapi:
                    context = 'local'
                    if self.is_in_domain():
                        context = 'domain'
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                    h = constant.user_dpapi.get_dpapi_hash(context=context)
                    if h:
                        pwd_found.append({
                            'Dpapi_hash_{context}'.format(context=context): constant.user_dpapi.get_dpapi_hash(
                                                                                                    context=context)
                        })
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
        return pwd_found
