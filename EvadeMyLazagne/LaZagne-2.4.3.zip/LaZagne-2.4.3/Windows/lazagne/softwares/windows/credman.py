# -*- coding: utf-8 -*- 
from lazagne.config.module_info import ModuleInfo
from lazagne.config.winstructure import *
#comment4
#comment2
class Credman(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'credman', 'windows', only_from_current_user=True)
#comment1
    def run(self):
        pwd_found = []
        #comment2
        creds = POINTER(PCREDENTIAL)()
        count = c_ulong()
#comment3
        if CredEnumerate(None, 0, byref(count), byref(creds)) == 1:
            for i in range(count.value):
                c = creds[i].contents
                if c.Type == CRED_TYPE_GENERIC or c.Type == CRED_TYPE_DOMAIN_VISIBLE_PASSWORD:
                    # Remove password too long
                    if c.CredentialBlobSize.real < 200:
                        pwd_found.append({
                            'URL': c.TargetName,
                            'Login': c.UserName,
                            'Password': c.CredentialBlob[:c.CredentialBlobSize.real]  # \\x00 could be deleted
                        })
#comment1
            CredFree(creds)
        return pwd_found
