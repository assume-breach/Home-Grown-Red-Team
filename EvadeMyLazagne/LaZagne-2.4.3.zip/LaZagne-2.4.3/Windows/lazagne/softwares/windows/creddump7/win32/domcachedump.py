#comment5
import hmac
import hashlib

from .rawreg import *
from ..addrspace import HiveFileAddressSpace
from .hashdump import get_bootkey
from .lsasecrets import get_secret_by_name, get_lsa_key
from struct import unpack
#comment1
from lazagne.config.crypto.pyaes.aes import AESModeOfOperationCBC
from lazagne.config.crypto.rc4 import RC4
#comment2
AES_BLOCK_SIZE = 16
#comment5
#comment2
def get_nlkm(secaddr, lsakey, vista):
    return get_secret_by_name(secaddr, 'NL$KM', lsakey, vista)
#comment5
#comment1
def decrypt_hash(edata, nlkm, ch):
    hmac_md5 = hmac.new(nlkm, ch, hashlib.md5)
    rc4key = hmac_md5.digest()
#comment3
    rc4 = RC4(rc4key)
    data = rc4.encrypt(edata)
    return data
#comment4
#comment1
def decrypt_hash_vista(edata, nlkm, ch):
    #comment5
    aes = AESModeOfOperationCBC(nlkm[16:32], iv=ch)
#comment1
    out = ""
    for i in range(0, len(edata), 16):
        buf = edata[i:i+16]
        if len(buf) < 16:
            buf += (16 - len(buf)) * "\00"
        out += b"".join([aes.decrypt(buf[i:i + AES_BLOCK_SIZE]) for i in range(0, len(buf), AES_BLOCK_SIZE)])
    return out
#comment3
#comment4
def parse_cache_entry(cache_data):
    (uname_len, domain_len) = unpack("<HH", cache_data[:4])
    (domain_name_len,) = unpack("<H", cache_data[60:62])
    ch = cache_data[64:80]
    enc_data = cache_data[96:]
    return uname_len, domain_len, domain_name_len, enc_data, ch
#comment2
#comment4
def parse_decrypted_cache(dec_data, uname_len, domain_len, domain_name_len):
    uname_off = 72
    pad = 2 * ((uname_len / 2) % 2)
    domain_off = uname_off + uname_len + pad
    pad = 2 * ((domain_len / 2) % 2)
    domain_name_off = domain_off + domain_len + pad
#comment1
    data_hash = dec_data[:0x10]
#comment2
    username = dec_data[uname_off:uname_off+uname_len]
    username = username.decode('utf-16-le', errors='ignore')
#comment3
    domain = dec_data[domain_off:domain_off+domain_len]
    domain = domain.decode('utf-16-le', errors='ignore')
#comment3
    domain_name = dec_data[domain_name_off:domain_name_off+domain_name_len]
    domain_name = domain_name.decode('utf-16-le', errors='ignore')
#comment5
    return username, domain, domain_name, data_hash
#comment2
#comment1
def dump_hashes(sysaddr, secaddr, vista):
    bootkey = get_bootkey(sysaddr)
    if not bootkey:
        return []
#comment3
    lsakey = get_lsa_key(secaddr, bootkey, vista)
    if not lsakey:
        return []
#comment4
    nlkm = get_nlkm(secaddr, lsakey, vista)
    if not nlkm:
        return []
#comment1
    root = get_root(secaddr)
    if not root:
        return []
#comment2
    cache = open_key(root, ["Cache"])
    if not cache:
        return []
#comment3
    hashes = []
    for v in values(cache):
        if v.Name == "NL$Control":
            continue
       #comment4 
        data = v.space.read(v.Data.value, v.DataLength.value)
#comment5
        (uname_len, domain_len, domain_name_len, enc_data, ch) = parse_cache_entry(data)
        #comment2
        #comment5
        if uname_len == 0:
            continue
#comment2
        if vista:
            dec_data = decrypt_hash_vista(enc_data, nlkm, ch)
        else:
            dec_data = decrypt_hash(enc_data, nlkm, ch)
#comment4
        (username, domain, domain_name, hash) = parse_decrypted_cache(dec_data, uname_len, domain_len, domain_name_len)
        hashes.append((username, domain, domain_name, hash))
#comment4
    return hashes 
#comment1
#comment2
def dump_file_hashes(syshive_fname, sechive_fname, vista):
    sysaddr = HiveFileAddressSpace(syshive_fname)
    secaddr = HiveFileAddressSpace(sechive_fname)
#comment4
    results = []
    for (u, d, dn, hash) in dump_hashes(sysaddr, secaddr, vista):
        results.append("%s:%s:%s:%s" % (u.lower(), hash.encode('hex'), d.lower(), dn.lower()))
    return results
