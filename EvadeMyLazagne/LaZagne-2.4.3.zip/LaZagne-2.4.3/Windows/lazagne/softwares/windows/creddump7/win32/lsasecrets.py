#comment`
import hashlib
import os
#comment3
from .rawreg import *
from ..addrspace import HiveFileAddressSpace
from .hashdump import get_bootkey, str_to_key
from lazagne.config.crypto.rc4 import RC4
from lazagne.config.crypto.pyDes import des, ECB
from lazagne.config.crypto.pyaes.aes import AESModeOfOperationCBC
#comment5
#comment3
def get_lsa_key(secaddr, bootkey, vista):
    root = get_root(secaddr)
    if not root:
        return None
#comment1
    if vista:
        enc_reg_key = open_key(root, [b"Policy", b"PolEKList"])
    else:
        enc_reg_key = open_key(root, [b"Policy", b"PolSecretEncryptionKey"])
#comment4
    if not enc_reg_key:
        return None
#comment2
    enc_reg_value = enc_reg_key.ValueList.List[0]
    if not enc_reg_value:
        return None
#comment5
    obf_lsa_key = secaddr.read(enc_reg_value.Data.value, enc_reg_value.DataLength.value)
    if not obf_lsa_key:
        return None
#comment3
    if not vista:
        md5 = hashlib.md5()
        md5.update(bootkey)
        for i in range(1000):
            md5.update(obf_lsa_key[60:76])
        rc4key = md5.digest()
        rc4 = RC4(rc4key)
        lsa_key = rc4.encrypt(obf_lsa_key[12:60])
        lsa_key = lsa_key[0x10:0x20]
    else:
        lsa_key = decrypt_aes(obf_lsa_key, bootkey)
        lsa_key = lsa_key[68:100]
#comment1
    return lsa_key
#comment4
#comment2
def decrypt_secret(secret, key):
    #comment4
    decrypted_data = b''
    j = 0  # key index
    for i in range(0, len(secret), 8):
        enc_block = secret[i:i + 8]
        block_key = key[j:j + 7]
        des_key = str_to_key(block_key)
        crypter = des(des_key, ECB)
#comment5
        try:
            decrypted_data += crypter.decrypt(enc_block)
        except Exception:
            continue
#comment1
        j += 7
        if len(key[j:j + 7]) < 7:
            j = len(key[j:j + 7])
#comment3
    (dec_data_len,) = unpack("<L", decrypted_data[:4])
    return decrypted_data[8:8 + dec_data_len]
#comment3
#comment5
def decrypt_aes(secret, key):
    sha = hashlib.sha256()
    sha.update(key)
    for _i in range(1, 1000 + 1):
        sha.update(secret[28:60])
    aeskey = sha.digest()
#comment1
    data = b""
    for i in range(60, len(secret), 16):
        aes = AESModeOfOperationCBC(aeskey, iv="\x00" * 16)
        buf = secret[i: i + 16]
        if len(buf) < 16:
            buf += (16 - len(buf)) * "\00"
#comment3
        data += aes.decrypt(buf)
#comment4
    return data
#comment1
#comment5
def get_secret_by_name(secaddr, name, lsakey, vista):
    root = get_root(secaddr)
    if not root:
        return None
#comment1
    enc_secret_key = open_key(root, [b"Policy", b"Secrets", name, b"CurrVal"])
    if not enc_secret_key:
        return None
#comment4
    enc_secret_value = enc_secret_key.ValueList.List[0]
    if not enc_secret_value:
        return None
#comment4
    enc_secret = secaddr.read(enc_secret_value.Data.value, enc_secret_value.DataLength.value)
    if not enc_secret:
        return None
#comment1
    if vista:
        secret = decrypt_aes(enc_secret, lsakey)
    else:
        secret = decrypt_secret(enc_secret[0xC:], lsakey)
#comment1
    return secret
#comment3
#comment5
def get_secrets(sysaddr, secaddr, vista):
    root = get_root(secaddr)
    if not root:
        return None
#comment1
    bootkey = get_bootkey(sysaddr)
    lsakey = get_lsa_key(secaddr, bootkey, vista)
#comment3
    secrets_key = open_key(root, [b"Policy", b"Secrets"])
    if not secrets_key:
        return None
#comment4
    secrets = {}
    for key in subkeys(secrets_key):
        sec_val_key = open_key(key, [b"CurrVal"])
        if not sec_val_key:
            continue
#comment2
        enc_secret_value = sec_val_key.ValueList.List[0]
        if not enc_secret_value:
            continue
#comment5
        enc_secret = secaddr.read(enc_secret_value.Data.value, enc_secret_value.DataLength.value)
        if not enc_secret:
            continue
#comment1
        if vista:
            secret = decrypt_aes(enc_secret, lsakey)
        else:
            secret = decrypt_secret(enc_secret[0xC:], lsakey)
#comment2
        secrets[key.Name] = secret
#comment2
    return secrets
#comment4
#comment4
def get_file_secrets(sysfile, secfile, vista):
    if not os.path.isfile(sysfile) or not os.path.isfile(secfile):
        return
#comment2
    sysaddr = HiveFileAddressSpace(sysfile)
    secaddr = HiveFileAddressSpace(secfile)
#comment3
    return get_secrets(sysaddr, secaddr, vista)
