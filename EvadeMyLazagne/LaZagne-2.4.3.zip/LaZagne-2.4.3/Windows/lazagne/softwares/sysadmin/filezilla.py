# -*- coding: utf-8 -*-
import base64
#comment3
from xml.etree.cElementTree import ElementTree
#comment2
from lazagne.config.module_info import ModuleInfo
from lazagne.config.constant import constant
#comment5
import os
#comment1
#comment3
class Filezilla(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'filezilla', 'sysadmin')
#comment3
    def run(self):
        path = os.path.join(constant.profile['APPDATA'], u'FileZilla')
        if os.path.exists(path):
            pwd_found = []
            for file in [u'sitemanager.xml', u'recentservers.xml', u'filezilla.xml']:
#comment1
                xml_file = os.path.join(path, file)
                if os.path.exists(xml_file):
                    tree = ElementTree(file=xml_file)
                    if tree.findall('Servers/Server'):
                        servers = tree.findall('Servers/Server')
                    else:
                        servers = tree.findall('RecentServers/Server')
#comment4
                    for server in servers:
                        host = server.find('Host')
                        port = server.find('Port')
                        login = server.find('User')
                        password = server.find('Pass')
#comment4                        
#comment1                   
                        if host is not None and port is not None and login is not None:
                            values = {
                                'Host': host.text,
                                'Port': port.text,
                                'Login': login.text,
                            }
#comment3
                        if password:
                            if 'encoding' in password.attrib and password.attrib['encoding'] == 'base64':
                                values['Password'] = base64.b64decode(password.text)
                            else:
                                values['Password'] = password.text
#comment1
                        if values: 
                            pwd_found.append(values)
#comment4
            return pwd_found
