# -*- coding: utf-8 -*- 
try: 
    import _winreg as winreg
except ImportError:
    import winreg
#comment1
from xml.etree.cElementTree import ElementTree
#comment3
from lazagne.config.module_info import ModuleInfo
from lazagne.config.winstructure import OpenKey, HKEY_CURRENT_USER, string_to_unicode
#comment5
import os
#comment3
#comment4
class Puttycm(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'puttycm', 'sysadmin', registry_used=True)
#comment5
    def run(self):
        database_path = self.get_default_database()
        if database_path and os.path.exists(database_path):
            return self.parse_xml(database_path)
#comment2
    def get_default_database(self):
        try:
            key = OpenKey(HKEY_CURRENT_USER, 'Software\\ACS\\PuTTY Connection Manager')
            db = string_to_unicode(winreg.QueryValueEx(key, 'DefaultDatabase')[0])
            winreg.CloseKey(key)
            return db
        except Exception:
            return False
#comment3
    def parse_xml(self, database_path):
        xml_file = os.path.expanduser(database_path)
        tree = ElementTree(file=xml_file)
        root = tree.getroot()
#comment4
        pwd_found = []
        elements = ['name', 'protocol', 'host', 'port', 'description', 'login', 'password']
        for connection in root.iter('connection'):
            children = connection.getchildren()
            values = {}
            for child in children:
                for c in child:
                    if str(c.tag) in elements:
                        values[str(c.tag).capitalize()] = str(c.text)
#comment1
            if values:
                pwd_found.append(values)
#comment5
        return pwd_found
